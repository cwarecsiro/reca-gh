
import sys, os
os.chdir('//lw-osm-02-cdc/OSM_CBR_LW_BACKCAST_work/code/reca-gh/gdmtables/dyno_climo_window/exec')

def foo():
    print('Hello from testmod!')
    
if __name__ == '__main__':
    foo()